import socket
import threading
from datetime import datetime

def receive_messages(client_socket):
    """Thread to continuously receive messages from the server."""
    try:
        while True:
            server_message = client_socket.recv(1024).decode('utf-8')
            if not server_message or server_message.strip().lower() == "bye":
                print("Server ended the conversation.")
                break
            timestamp = datetime.now().strftime("%Y/%m/%d %H:%M:%S")
            print(f"[{timestamp}] {server_message}")
    except Exception as e:
        print(f"Error in receiving messages: {e}")
    finally:
        client_socket.close()

def send_messages(client_socket):
    """Thread to continuously send messages to the server."""
    try:
        while True:
            message = input("You: ")
            client_socket.sendall(message.encode('utf-8'))
            if message.strip().lower() == "bye":
                print("Ending conversation...")
                break
    except Exception as e:
        print(f"Error in sending messages: {e}")
    finally:
        client_socket.sendall("bye".encode('utf-8'))  # Notify server to close the conversation
        client_socket.close()

def main():
    host = "127.0.0.1"
    port = 65432

    try:
        # Create a client socket
        client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client_socket.connect((host, port))

        # Receive and display the server's greeting message
        greeting = client_socket.recv(1024).decode('utf-8')
        print(greeting)

        # Create threads for sending and receiving messages
        send_thread = threading.Thread(target=send_messages, args=(client_socket,))
        receive_thread = threading.Thread(target=receive_messages, args=(client_socket,))

        # Start the threads
        send_thread.start()
        receive_thread.start()

        # Wait for both threads to complete
        send_thread.join()
        receive_thread.join()

    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    main()
