import socket

def udp_server():
    try:
        # Create a UDP socket
        server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        server_socket.bind(('127.0.0.1', 65432))
        print("Server is listening on port 65432...")

        while True:
            # Receive data from the client
            data, client_address = server_socket.recvfrom(1024)
            client_message = data.decode()
            print(f"Received from client: {client_message}")

            # Prepare and send response to client
            response = f"Server received: {client_message}"
            server_socket.sendto(response.encode(), client_address)
            print("Response sent to client.")

            # Exit if the client message is "bye"
            if client_message.strip().lower() == "bye":
                print("Server exiting...")
                break

        # Close the socket
        server_socket.close()

    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    udp_server()
