import socket

def udp_client():
    try:
        client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        server_address = ('127.0.0.1', 65432)

        while True:
            # Read message from user
            message = input("You: ")
            client_socket.sendto(message.encode(), server_address)
            print(f"Sent to server: {message}")

            # Exit if the message is "bye"
            if message.strip().lower() == "bye":
                print("Ending conversation...")
                break

            # Receive response from server
            data, _ = client_socket.recvfrom(1024)
            server_response = data.decode()
            print(f"Received from server: {server_response}")

        # Close the socket
        client_socket.close()

    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    udp_client()
