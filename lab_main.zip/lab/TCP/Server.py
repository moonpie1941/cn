import socket
import threading
from datetime import datetime

def send_messages(client_socket):
    """Thread for sending messages to the client."""
    try:
        while True:
            message = input("Server: ")
            client_socket.sendall(message.encode('utf-8'))
            if message.strip().lower() == "bye":
                print("Ending conversation with the client...")
                break
    except Exception as e:
        print(f"Error in sending messages: {e}")
    finally:
        client_socket.sendall("bye".encode('utf-8'))  # Notify client to close the conversation
        client_socket.close()

def receive_messages(client_socket):
    """Thread for receiving messages from the client."""
    try:
        while True:
            client_message = client_socket.recv(1024).decode('utf-8')
            if not client_message or client_message.strip().lower() == "bye":
                print("Client ended the conversation.")
                break

            timestamp = datetime.now().strftime("%Y/%m/%d %H:%M:%S")
            print(f"[{timestamp}] Client: {client_message}")
    except Exception as e:
        print(f"Error in receiving messages: {e}")
    finally:
        client_socket.close()

def main():
    host = "127.0.0.1"
    port = 65432

    try:
        # Create a server socket
        server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server_socket.bind((host, port))
        server_socket.listen(1)
        print(f"Server listening on {host}:{port}...")

        client_socket, client_address = server_socket.accept()
        print(f"Connected to client: {client_address}")

        # Create threads for sending and receiving messages
        send_thread = threading.Thread(target=send_messages, args=(client_socket,))
        receive_thread = threading.Thread(target=receive_messages, args=(client_socket,))

        # Start the threads
        send_thread.start()
        receive_thread.start()

        # Wait for both threads to complete
        send_thread.join()
        receive_thread.join()

    except Exception as e:
        print(f"Error: {e}")
    finally:
        server_socket.close()
        print("Server shut down.")

if __name__ == "__main__":
    main()
